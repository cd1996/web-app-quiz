var jsonData = [
    {
        "q" : "The common element which describe the web page, is ?",
        "opt1" : "heading",
        "opt2" : "paragraph",
        "opt3" : "All of these",
        "answer" : "All of these"
    },
    {
        "q" : "HTML stands for?",
        "opt1" : "Hyper Text Markup Language",
        "opt2" : "High Text Markup Language",
        "opt3" : "Hyper Tabular Markup Language",
        "answer" : "Hyper Text Markup Language"
    },
    {
        "q" : "which of the following tag is used to mark a begining of paragraph ?",
        "opt1" : "TD",
        "opt2" : "br",
        "opt3" : "P",
        "answer" : "P"
    },
    {
        "q" : "From which tag descriptive list starts ?",
        "opt1" : "LL",
        "opt2" : "DL",
        "opt3" : "DD",
        "answer" : "DL"
    },
    {
        "q" : "Correct HTML tag for the largest heading is _____",
        "opt1" : "h1",
        "opt2" : "h6",
        "opt3" : "heading",
        "answer" : "h1"
    }
];